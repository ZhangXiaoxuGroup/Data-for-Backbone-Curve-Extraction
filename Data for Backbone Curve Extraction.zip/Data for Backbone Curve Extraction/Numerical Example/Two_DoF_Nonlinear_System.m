function Two_DoF_Nonlinear_System
clc; clear; close all;
omega1=5; omega2=6.5; eta1=8; eta2=4; eta3=12; eta4=12; eta5=-4; mu1=0.04; mu2=0.06;
tspan=[0,100]; t=0:0.001:100;
options=odeset('AbsTol',1e-12*ones(4,1),'RelTol',1e-12,'MaxStep',0.001);
y0=[0.5;0.01;-0.01;0.01];
[T,Y]=ode45(@(t,y)MyFun(t,y),tspan,y0,options);
u11=interp1(T,Y(:,1),t,'spline');
u21=interp1(T,Y(:,2),t,'spline');
y0=[-0.01;0.5;0.01;-0.01];
[T,Y]=ode45(@(t,y)MyFun(t,y),tspan,y0,options);
u12=interp1(T,Y(:,1),t,'spline');
u22=interp1(T,Y(:,2),t,'spline');

save('Simulated Data.mat','t','u11','u21','u12','u22');

h_f=figure(1);
set(h_f,'Position',[50,50,700,400])
subplot(2,1,1)
plot(t,u11,'b','LineWidth',1)
hold on
plot(t,-2*mu1/pi/omega1*t+0.5,'k','LineWidth',1)
hold on
plot(t,2*mu1/pi/omega1*t-0.5,'k','LineWidth',1)
xlim([0,100])
ylim([-0.7,0.7])
xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$y_{1,1}(t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
set(gca,'FontName','Times New Roman','FontSize',12)

subplot(2,1,2)
plot(t,u21,'b','LineWidth',1)
hold on
plot(t,-0.01*exp(-mu2/2*t),'k','LineWidth',1)
hold on
plot(t,0.01*exp(-mu2/2*t),'k','LineWidth',1)
xlim([0,100])
ylim([-0.015,0.015])
xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$y_{2,1}(t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
set(gca,'FontName','Times New Roman','FontSize',12)

h_f=figure(2);
set(h_f,'Position',[50,50,700,400])
subplot(2,1,1)
plot(t,u12,'b','LineWidth',1)
hold on
a22=exp(-mu2/2*t)*0.5;
s12=-eta1*a22.^2/(2*omega1^2);
h1=plot(t,s12,'k','LineWidth',1);
xlim([0,100])
ylim([-0.08,0.02])
xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$y_{1,2}(t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
legend(h1,'Streaming')
set(gca,'FontName','Times New Roman','FontSize',12)

subplot(2,1,2)
plot(t,u22,'b','LineWidth',1)
hold on
plot(t,exp(-mu2/2*t)*0.5,'k','LineWidth',1)
hold on
plot(t,-exp(-mu2/2*t)*0.5,'k','LineWidth',1)
xlim([0,100])
ylim([-0.7,0.7])
xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$y_{2,2}(t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
set(gca,'FontName','Times New Roman','FontSize',12)

function dydt=MyFun(t,y)
omega1=5; omega2=6.5; eta1=8; eta2=4; eta3=12; eta4=12; eta5=-4; mu1=0.04; mu2=0.06;
dydt=[y(3);...
    y(4);...
    -omega1^2*y(1)-eta1*y(2)^2-mu1*atan(10000*y(3))/pi*2-eta2*y(1)^3-eta3*y(1)*y(2)^2;...
    -omega2^2*y(2)-mu2*y(4)-eta4*y(1)^2*y(2)-eta5*y(2)^3];
