function [T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction_Fourier(t,u)
NT=length(t); dt=t(2)-t(1);
U_Env=[];
L_Env=[];
Omega_Inst=[];
N_Count=500;

f1=4/2/pi;
f2=7/2/pi;
m=2048;
fs=1/dt;
fn=(0:m-1)/m;
fz=(f2-f1)*fn+f1;
w=exp(-1i*2*pi*(f2-f1)/(m*fs));
a = exp(1i*2*pi*f1/fs);

N_Gap=max(N_Count,round(m/2));
for n=(N_Gap+1):(NT-N_Gap)
    if u(n) == max(u((-N_Count:N_Count)+n))
        U_Env=[U_Env,[t(n);u(n)]];
        y=u((-round(m/2):(round(m/2)-1))+n);
        y=y-mean(y);
        z = czt(y,m,w,a);
        [~,Index]=max(abs(z));
        Omega_Inst=[Omega_Inst,fz(Index)*2*pi];
    end
    if u(n) == min(u((-N_Count:N_Count)+n))
        L_Env=[L_Env,[t(n);u(n)]];
        y=u((-round(m/2):(round(m/2)-1))+n);
        y=y-mean(y);
        z = czt(y,m,w,a);
        [~,Index]=max(abs(z));
        Omega_Inst=[Omega_Inst,fz(Index)*2*pi];
    end
end
N_U_Env=length(U_Env(1,:));
N_L_Env=length(L_Env(1,:));
T=[(U_Env(1,2:N_U_Env)+U_Env(1,1:(N_U_Env-1)))/2,(L_Env(1,2:N_L_Env)+L_Env(1,1:(N_L_Env-1)))/2];
T=sort(T);
U_A=interp1(U_Env(1,:),U_Env(2,:),t,'linear');
L_A=interp1(L_Env(1,:),L_Env(2,:),t,'linear');
A_Inst=(U_A-L_A)/2;
V_Inst=(A_Inst(2:end)-A_Inst(1:(end-1)))/(t(2)-t(1));
A_Inst=interp1(t,A_Inst,T,'linear');
V_Inst=interp1((t(2:end)+t(1:(end-1)))/2,V_Inst,T,'linear');
Omega_Inst=interp1([U_Env(1,:),L_Env(1,:)],Omega_Inst,T,'linear');