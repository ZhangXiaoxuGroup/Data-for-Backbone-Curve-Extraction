function [T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction_Peak(t,u)
NT=length(t);
U_Env=[];
L_Env=[];
N_Count=400;
for n=(N_Count+1):(NT-N_Count)
    if u(n) == max(u((-N_Count:N_Count)+n))
        U_Env=[U_Env,[t(n);u(n)]];
    end
    if u(n) == min(u((-N_Count:N_Count)+n))
        L_Env=[L_Env,[t(n);u(n)]];
    end
end
N_U_Env=length(U_Env(1,:));
N_L_Env=length(L_Env(1,:));
T=[(U_Env(1,2:N_U_Env)+U_Env(1,1:(N_U_Env-1)))/2,(L_Env(1,2:N_L_Env)+L_Env(1,1:(N_L_Env-1)))/2];
[T,Index]=sort(T);
Omega_Inst=2*pi./[U_Env(1,2:N_U_Env)-U_Env(1,1:(N_U_Env-1)),L_Env(1,2:N_L_Env)-L_Env(1,1:(N_L_Env-1))];
Omega_Inst=Omega_Inst(Index);
U_A=interp1(U_Env(1,:),U_Env(2,:),t,'linear');
L_A=interp1(L_Env(1,:),L_Env(2,:),t,'linear');
A_Inst=(U_A-L_A)/2;
V_Inst=(A_Inst(2:end)-A_Inst(1:(end-1)))/(t(2)-t(1));
A_Inst=interp1(t,A_Inst,T,'linear');
V_Inst=interp1((t(2:end)+t(1:(end-1)))/2,V_Inst,T,'linear');