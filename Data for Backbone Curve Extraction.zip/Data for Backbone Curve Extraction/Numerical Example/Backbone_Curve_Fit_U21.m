function Backbone_Curve_Fit_U21
clc; clear; close all;
Data=load('Simulated Data.mat');
t=Data.t;
u=Data.u21;


omega1=4.999741597338151; eta2=4.001789334151419; mu1=0.039580369968436;
Omeg_Mean=6.5; Slide_Ratio=0.2; A0=0.02; zeta0=0.02; N_Period=3;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,~,~,Omega_Inst,~]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0);
A_Inst=max(0.5-2*mu1/pi/omega1*T,0);
h_f=figure(1);
set(h_f,'Position',[50,50,300,200])
h1=scatter(Omega_Inst,A_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([6.45,6.75])
ylim([0,0.55])
xlabel('$\omega_{2,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

Para0=5;
lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,A_Inst,Omega_Inst,[],[],lsq_options)
figure(1)
hold on
text(6.47,0.51,'$\omega_{2,1}=\omega_2+\varepsilon \eta_4 \frac{a_{1,1}^2}{4\omega_2}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h3=plot(Backbone_Fit(Para,A_Inst),A_Inst,'k','LineWidth',1.5);

function y=Backbone_Fit(Para,x)
omega2=6.499900457724624; eta4=Para;
y=omega2+eta4*x.^2/(4*omega2);
