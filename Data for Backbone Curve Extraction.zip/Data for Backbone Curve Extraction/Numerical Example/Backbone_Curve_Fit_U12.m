function Backbone_Curve_Fit_U12
clc; clear; close all;
Data=load('Simulated Data.mat');
t=Data.t; NT=length(t);
u22=Data.u22;
u12=Data.u12;

Para0=[0.5;0];
lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para=lsqcurvefit(@(Para,t)ResponseFit(Para,t),Para0,t,u22,[],[],lsq_options);
a22_Amp=Para(1);
omega1=4.999741633472116; omega2=6.499892033023232; eta5=-3.954093970111158; mu2=0.060176670635202;
a22_Inst=a22_Amp*exp(-mu2/2*t);
omega22=eta5*(3*a22_Inst.^2)/(8*omega2);
phi22_Inst=cumtrapz(t,omega22)+Para(2);
u22=a22_Inst.*cos(omega2*t+phi22_Inst);
U22=fft(2*u22.^2)/NT*2;
U12=fft(u12)/NT*2;
N=round(2*omega2/(2*pi/(t(end)-t(1))));
[~,Index]=max(abs(U12((-10:10)+N)));
if Index ~= 1 && Index ~= 21
    N=N+Index-11;
    u=u12-abs(U12(1))/abs(U22(1))*a22_Inst.^2*cos(angle(U12(1))-angle(U22(1)))...
        -abs(U12(N))/abs(U22(N))*a22_Inst.^2.*cos(2*omega2*t+2*phi22_Inst+angle(U12(N))-angle(U22(N)));
else
    u=u21;
end
N_Omega=300;
Omeg=2*pi*((1:N_Omega)-1)/(t(end)-t(1));
U=fft(u)/NT*2;

-abs(U12(1))/abs(U22(1))*cos(angle(U12(1))-angle(U22(1)))*2*omega1^2

h_f=figure(1);
set(h_f,'Position',[50,50,300,300])
% plot(t,u12,'r','LineWidth',1)
% hold on
plot(t,u,'b','LineWidth',1)
grid on
xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$\tilde{y}_{1,2}(t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
set(gca,'FontName','Times New Roman','FontSize',11)
xlim([0,12])
ylim([-0.025,0.025])

h_f=figure(2);
set(h_f,'Position',[50,50,600,300])
area(Omeg,abs(U12(1:N_Omega)),'FaceColor','y','FaceAlpha',0.4,'EdgeColor','None');
hold on
h1=plot(Omeg,abs(U12(1:N_Omega)),'r','LineWidth',1.5);
hold on
h2=plot(Omeg,abs(U(1:N_Omega)),'b','LineWidth',1.5);
hl=legend([h1,h2],'$y_{1,2}$','$\tilde{y}_{1,2}$');
set(hl,'Interpreter','Latex','FontName','Times New Roman','FontSize',11,'Location','NorthEast','Color','none','EdgeColor','none')
grid on
xlabel('$\omega$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$Amplitude$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
set(gca,'FontName','Times New Roman','FontSize',11)
xlim([0,15])
% ylim([-0.001,0.015])

Omeg_Mean=5; Slide_Ratio=0.1; A0=0.02; zeta0=0.02; N_Period=2;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,A_Inst,~,Omega_Inst]=Instant_AmpOmega_Extraction_Sliding(t(1:12000),u(1:12000),Omeg_Mean,Slide_Ratio,N_Period,Para0);
figure(1)
hold on
plot(T,A_Inst,'o','MarkerFaceColor','k','MarkerSize',4)

U22_Inst=a22_Amp*exp(-mu2/2*T);
h_f=figure(3);
set(h_f,'Position',[50,50,300,300])
h1=scatter(Omega_Inst,U22_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([4.98,5.2])
ylim([0,0.55])
xlabel('$\omega_{1,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para0=10;
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,U22_Inst,Omega_Inst,[],[],lsq_options)
figure(3)
hold on
text(5.05,0.11,'$\omega_{1,2}=\omega_1+\varepsilon \eta_3 \frac{a_{2,2}^2}{4\omega_1}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h3=plot(Backbone_Fit(Para,a22_Amp*exp(-mu2/2*t)),a22_Amp*exp(-mu2/2*t),'k','LineWidth',1.5);
% h_l=legend([h1,h3],'Extracted samples','Fitted curve');
set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Southeast','EdgeColor','none','Color','none','TextColor','b')


function y=ResponseFit(Para,t)
omega2=6.499892033023232; eta5=-3.954093970111158; mu2=0.060176670635202;
a22=Para(1)*exp(-mu2/2*t);
omega22=eta5*(3*a22.^2)/(8*omega2);
phi22=cumtrapz(t,omega22);
y=a22.*cos(omega2*t+phi22+Para(2));

function y=Backbone_Fit(Para,x)
omega1=4.999741633472116; eta3=Para;
y=omega1+eta3*x.^2/(4*omega1);