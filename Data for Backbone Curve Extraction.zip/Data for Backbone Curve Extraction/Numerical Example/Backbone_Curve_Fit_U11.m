function Backbone_Curve_Fit_U11
clc; clear; close all;
Data=load('Simulated Data.mat');
t=Data.t;
u=Data.u11;
Omeg_Mean=5; Slide_Ratio=0.2; A0=0.5; zeta0=0.02; N_Period=2;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0);
% [T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction(t,u);
h_f=figure(1);
set(h_f,'Position',[50,50,300,300])
h1=scatter(Omega_Inst,A_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([4.98,5.1])
ylim([0,0.55])
xlabel('$\omega_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)
h_f=figure(2);
set(h_f,'Position',[100,100,300,300])
h2=scatter(A_Inst,100*V_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,0.5])
ylim([-1,0])
xlabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$\dot{a}_{1,1}(\varepsilon t)(\times 100)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

Index=find(A_Inst>0.1);
T=T(Index);
A_Inst=A_Inst(Index);
V_Inst=V_Inst(Index);
Omega_Inst=Omega_Inst(Index);

lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para0=[5,5];
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,A_Inst,Omega_Inst,[],[],lsq_options)
figure(1)
hold on
text(4.99,0.51,'$\omega_{1,1}=\omega_1+\varepsilon \eta_2 \frac{3a_{1,1}^2}{8\omega_1}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h3=plot(Backbone_Fit(Para,A_Inst),A_Inst,'k','LineWidth',1.5);
h_l=legend([h1,h3],'Extracted samples','Fitted curve');
set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Southeast','EdgeColor','none','Color','none','TextColor','b')
Para0=0.02;
Para=lsqcurvefit(@(Para,x)Amp_Velo_Fit(Para,x),Para0,A_Inst,V_Inst,[],[],lsq_options)
figure(2)
hold on
text(0.05,-0.9,'$\dot{a}_{1,1}=-\varepsilon \mu_1 a_{1,1}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h4=plot(A_Inst,100*Amp_Velo_Fit(Para,A_Inst),'k','LineWidth',1.5);
h_l=legend([h2,h4],'Extracted samples','Fitted curve');
set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Northeast','EdgeColor','none','Color','none','TextColor','b')

function y=Amp_Velo_Fit(Para,x)
mu1=Para;
y=-2*mu1*ones(size(x))/4.999741597338151/pi;

function y=Backbone_Fit(Para,x)
omega1=Para(1); eta2=Para(2);
y=omega1+3*eta2*x.^2/(8*omega1);