function Backbone_Curve_Fit_U22
clc; clear; close all;
Data=load('Simulated Data.mat');
t=Data.t;
u=Data.u22;
Omeg_Mean=6.5; Slide_Ratio=0.2; A0=0.5; zeta0=0.02; N_Period=2;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0);
% [T,A_Inst,V_Inst,Omega_Inst]=Instant_AmpOmega_Extraction(t,u);
h_f=figure(1);
set(h_f,'Position',[50,50,300,300])
h1=scatter(Omega_Inst,A_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([6.40,6.52])
ylim([0,0.55])
xlabel('$\omega_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$a_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)
h_f=figure(2);
set(h_f,'Position',[100,100,300,300])
h2=scatter(A_Inst,100*V_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,0.5])
ylim([-1.7,0])
xlabel('$a_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$\dot{a}_{2,2}(\varepsilon t)(\times 100)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para0=[5,5];
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,A_Inst,Omega_Inst,[],[],lsq_options)
figure(1)
hold on
text(6.41,0.51,'$\omega_{2,2}=\omega_2+\varepsilon \eta_5 \frac{3a_{2,2}^2}{8\omega_2}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h3=plot(Backbone_Fit(Para,A_Inst),A_Inst,'k','LineWidth',1.5);
h_l=legend([h1,h3],'Extracted samples','Fitted curve');
set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Southwest','EdgeColor','none','Color','none','TextColor','b')
Para0=0.02;
Para=lsqcurvefit(@(Para,x)Amp_Velo_Fit(Para,x),Para0,A_Inst,V_Inst,[],[],lsq_options)
figure(2)
hold on
text(0.05,-1.6,'$\dot{a}_{2,2}=-\varepsilon \mu_2 a_{2,2}$',...
    'Interpreter','Latex','FontName','Times New Roman','FontSize',12)
h4=plot(A_Inst,100*Amp_Velo_Fit(Para,A_Inst),'k','LineWidth',1.5);
h_l=legend([h2,h4],'Extracted samples','Fitted curve');
set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Northeast','EdgeColor','none','Color','none','TextColor','b')

function y=Amp_Velo_Fit(Para,x)
mu2=Para;
y=-mu2*x/2;

function y=Backbone_Fit(Para,x)
omega2=Para(1); eta5=Para(2);
y=omega2+3*eta5*x.^2/(8*omega2);