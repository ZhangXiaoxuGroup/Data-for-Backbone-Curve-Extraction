function Backbone_Curve_Fit_U22
clc; clear; close all;
Data=load('Experimental Data.mat');
t=Data.t;
u=Data.u22*100;
% plot(t,u,'r','LineWidth',1)
Omeg_Mean=41.5; Slide_Ratio=0.2; A0=2; zeta0=0.02; N_Period=6;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0);
% [T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction(t,u);
% hold on
% plot(T,A_Inst,'b','LineWidth',1)
% 
% figure(2)
% plot(T,Omega_Inst,'b','LineWidth',1)
% 
% figure(3)
% plot(Omega_Inst,A_Inst)

h_f=figure(1);
set(h_f,'Position',[50,50,300,300])
h1=scatter(Omega_Inst,A_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([41,48])
ylim([0,1.8])
xlabel('$\omega_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$a_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)
h_f=figure(2);
set(h_f,'Position',[100,100,300,300])
h2=scatter(A_Inst,V_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,1.8])
ylim([-0.22,0])
xlabel('$a_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$\dot{a}_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

h_f=figure(3);
set(h_f,'Position',[50,50,300,300])
h3=scatter(A_Inst.^2,Stream,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,3])
ylim([-0.4,0.4])
xlabel('$a_{2,2}^2(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$s_{2,2}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para0=[42,5];
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,A_Inst,Omega_Inst,[],[],lsq_options);
omega2=Para(1)
eta4=Para(2)
figure(1)
hold on
% text(41.2,0.013,'$\omega_{2,2}=\omega_2+\varepsilon \eta _4\frac{3a_{2,2}^2}{8\omega_2}$',...
%     'Interpreter','Latex','FontName','Times New Roman','FontSize',12);
h4=plot(Backbone_Fit(Para,A_Inst),A_Inst,'k','LineWidth',1.5);
% h_l=legend([h1,h4],'Extracted samples','Fitted curve');
% set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Southeast','EdgeColor','none','Color','none','TextColor','b')

Para0=0.02;
Para=lsqcurvefit(@(Para,x)Amp_Velo_Fit(Para,x),Para0,A_Inst,V_Inst,[],[],lsq_options);
mu2=Para
figure(2)
hold on
% text(0.001,-0.17,'$\dot{a}_{2,2}=-\varepsilon \mu_2 a_{2,2}$',...
%     'Interpreter','Latex','FontName','Times New Roman','FontSize',12);
h5=plot(A_Inst,Amp_Velo_Fit(Para,A_Inst),'k','LineWidth',1.5);
% h_l=legend([h2,h5],'Extracted samples','Fitted curve');
% set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Northeast','EdgeColor','none','Color','none','TextColor','b')

Para0=1;
Para=lsqcurvefit(@(Para,x)Stream_Fit(Para,x,omega2),Para0,A_Inst.^2,Stream,[],[],lsq_options);
eta3=Para
figure(3)
hold on
h6=plot(A_Inst.^2,Stream_Fit(Para,A_Inst.^2,omega2),'k','LineWidth',1.5);
% h_l=legend([h2,h6],'Extracted samples','Fitted curve');
% set(h_l,'FontName','Times New Roman','FontSize',12,'Location','Northeast','EdgeColor','none','Color','none','TextColor','b')

function y=Amp_Velo_Fit(Para,x)
mu2=Para;
y=-mu2*x/2;

function y=Backbone_Fit(Para,x)
omega2=Para(1); eta4=Para(2);
y=omega2+3*eta4*x.^2/(8*omega2);

function y=Stream_Fit(Para,x,omega2)
eta3=Para;
y=-eta3*x/(2*omega2^2);