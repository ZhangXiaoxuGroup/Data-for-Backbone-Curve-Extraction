function Backbone_Curve_Fit_U21_OptimalDeltaOmega
clc; clear; close all;
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
omega1=27.047306461832289;
mu1=0.134586766424387;
omega2=41.664389159075455;
mu2=0.205513124478225;
eta2=44.161879686317661;
eta3=-5.850728871964156e+02;
eta4=2.421443508328958e+02;

Data=load('Experimental Data.mat');
t=Data.t'; NT=length(t);
u11=Data.u11'*100;
u21=Data.u21'*100;

Para0=[1.8;0];
lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para=lsqcurvefit(@(Para,t)ResponseFit(Para,t),Para0,t,u11,[],[],lsq_options);
a11_Inst=Para(1)*exp(-mu1/2*t);
omega11=omega1+eta2*(3*a11_Inst.^2)/(8*omega1);
phi11_Inst=cumtrapz(t,omega11)+Para(2);
h2=a11_Inst.^2.*cos(2*phi11_Inst)/2;
U21=fft(u21)/NT*2;
H2=fft(h2)/NT*2;

N=round(2*omega1/(2*pi/(t(end)-t(1))));

delta_w=5:0.5:10;
Ld=length(delta_w);
Eta1=zeros(1,Ld);
Ratio=zeros(1,Ld);
for i=1:Ld
    N_delta=round(delta_w(i)/(2*pi/(t(end)-t(1))));
    Eta1(i)=-H2((N-N_delta):(N+N_delta))\U21((N-N_delta):(N+N_delta))*(omega2^2-4*omega1^2);
    Ratio(i)=abs(imag(Eta1(i))/real(Eta1(i)))*100;
end
h_f=figure(1);
set(h_f,'Position',[50,50,400,300])
bar(delta_w,Ratio,'FaceColor','b','EdgeColor','None','BarWidth',0.6)
xlabel('$\delta \omega$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$\rho \left( \%  \right)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
set(gca,'FontName','Times New Roman','FontSize',11,'YScale','log')
ylim([1e-3,1e3])

function y=ResponseFit(Para,t)
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
a11=Para(1)*exp(-mu1/2*t);
omega11=eta2*(3*a11.^2)/(8*omega1);
phi11=cumtrapz(t,omega11);
y=a11.*cos(omega1*t+phi11+Para(2));