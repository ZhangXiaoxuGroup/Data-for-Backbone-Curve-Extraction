function [T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0)
N_t=length(t); dt=t(2)-t(1);
Win_Width=N_Period*2*pi/Omeg_Mean; N_Win=round(Win_Width/dt); N_Slide_Ratio=round(N_Win*Slide_Ratio);
N_T=floor((N_t-N_Win)/N_Slide_Ratio);
T=zeros(1,N_T); A_Inst=zeros(1,N_T); V_Inst=zeros(1,N_T); Omega_Inst=zeros(1,N_T); Stream=zeros(1,N_T);
lsq_options=optimset('TolFun',1e-8,'TolX',1e-8,'Display','off');
for n=1:N_T
    Para=lsqcurvefit(@(Para,t)Fun_for_Fit(Para,t),Para0,(1:N_Win)*dt,...
        u((n-1)*N_Slide_Ratio+(1:N_Win)),[],[],lsq_options);
    Omega0=Para(1);
    A0=Para(2); zeta=Para(3); Phi=Para(4);
    S0=Para(5); gamma0=Para(6);
    S2=Para(7); gamma2=Para(8); theta2=Para(9);
    S3=Para(10); gamma3=Para(11); theta3=Para(12);
    Para0=[Omega0,A0*exp(-zeta*N_Slide_Ratio*dt),zeta,Omega0*N_Slide_Ratio*dt+Phi,...
       S0*exp(-gamma0*N_Slide_Ratio*dt),gamma0,...
       S2*exp(-gamma2*N_Slide_Ratio*dt),gamma2, 2*Omega0*N_Slide_Ratio*dt+theta2,...
       S3*exp(-gamma3*N_Slide_Ratio*dt),gamma3, 3*Omega0*N_Slide_Ratio*dt+theta3];
    T(n)=(t((n-1)*N_Slide_Ratio+1)+t((n-1)*N_Slide_Ratio+N_Win))/2;
    Omega_Inst(n)=Omega0;
    A_Inst(n)=A0*exp(-zeta*N_Win*dt/2);
    V_Inst(n)=-zeta*A0*exp(-zeta*N_Win*dt/2);
    Stream(n)=S0*exp(-gamma0*N_Win*dt/2);
end

function uf=Fun_for_Fit(Para,t)
Omega0=Para(1); 
A0=Para(2); zeta=Para(3); Phi=Para(4); 
S0=Para(5); gamma0=Para(6);
S2=Para(7); gamma2=Para(8); theta2=Para(9);
S3=Para(10); gamma3=Para(11); theta3=Para(12);
uf=A0*exp(-zeta*t).*cos(Omega0*t+Phi)+S0*exp(-gamma0*t)+...
    S2*exp(-gamma2*t).*cos(2*Omega0*t+theta2)+S3*exp(-gamma3*t).*cos(3*Omega0*t+theta3);