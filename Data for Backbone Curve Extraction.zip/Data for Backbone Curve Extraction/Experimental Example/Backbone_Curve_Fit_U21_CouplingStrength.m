function Backbone_Curve_Fit_U21_CouplingStrength
clc; clear; close all;
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
omega1=27.047306461832289;
mu1=0.134586766424387;
omega2=41.664389159075455;
mu2=0.205513124478225;
eta2=44.161879686317661;
eta3=-4.336501874393491e+02;
eta4=2.421443508328958e+02;

Data=load('Experimental Data.mat');
t=Data.t'; NT=length(t);
u11=Data.u11'*100;
u21=Data.u21'*100;

Para0=[1.8;0];
lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para=lsqcurvefit(@(Para,t)ResponseFit(Para,t),Para0,t,u11,[],[],lsq_options);
a11_Inst=Para(1)*exp(-mu1/2*t);
omega11=omega1+eta2*(3*a11_Inst.^2)/(8*omega1);
phi11_Inst=cumtrapz(t,omega11)+Para(2);
h2=a11_Inst.^2.*cos(2*phi11_Inst)/2;
U21=fft(u21)/NT*2;
H2=fft(h2)/NT*2;

N=round(2*omega1/(2*pi/(t(end)-t(1))));
delta_w=7.5;
N_delta=round(delta_w/(2*pi/(t(end)-t(1))));
eta1=-H2((N-N_delta):(N+N_delta))\U21((N-N_delta):(N+N_delta))*(omega2^2-4*omega1^2)
I_eta1=imag(eta1);
eta1=real(eta1);
ratio=abs(I_eta1/eta1)*100

u=u21+eta1*a11_Inst.^2/(2*omega2^2)+eta1*a11_Inst.^2.*cos(2*phi11_Inst)/(2*(omega2^2-4*omega1^2));

U=fft(u)/NT*2;
N_Omega=800;
df=1/(t(end)-t(1));
Freq=((1:N_Omega)-1)*df*2*pi;
h_f=figure(1);
set(h_f,'Position',[50,50,300,180])
h1=plot(Freq,abs(U21(1:N_Omega)),'r','LineWidth',1.5);
hold on
h2=plot(Freq,abs(U(1:N_Omega)),'b','LineWidth',1.5);
hl=legend([h1,h2],'$y_{2,1}$','$\tilde{y}_{2,1}$');
set(hl,'Interpreter','Latex','FontName','Times New Roman','FontSize',11,'Location','NorthEast','Color','none','EdgeColor','none')
grid on
xlim([0,70])
ylim([0,0.03])
xlabel('$\omega$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$Amplitude$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
set(gca,'FontName','Times New Roman','FontSize',11)


function y=ResponseFit(Para,t)
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
a11=Para(1)*exp(-mu1/2*t);
omega11=eta2*(3*a11.^2)/(8*omega1);
phi11=cumtrapz(t,omega11);
y=a11.*cos(omega1*t+phi11+Para(2));