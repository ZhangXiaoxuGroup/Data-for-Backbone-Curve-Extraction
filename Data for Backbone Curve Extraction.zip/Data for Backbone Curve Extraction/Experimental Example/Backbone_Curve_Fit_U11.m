function Backbone_Curve_Fit_U11
clc; clear; close all;
Data=load('Experimental Data.mat');
t=Data.t;
u=Data.u11*100;
% plot(t,u,'r','LineWidth',1)
Omeg_Mean=27; Slide_Ratio=0.2; A0=2; zeta0=0.02; N_Period=6;
Para0=zeros(1,12);
Para0(1:3)=[Omeg_Mean,A0,zeta0];
[T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction_Sliding(t,u,Omeg_Mean,Slide_Ratio,N_Period,Para0);
% [T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction(t,u);
% hold on
% plot(T,A_Inst,'b','LineWidth',1)
% 
% figure(2)
% plot(T,Omega_Inst,'b','LineWidth',1)
% 
% figure(3)
% plot(Omega_Inst,A_Inst)

h_f=figure(1);
set(h_f,'Position',[50,50,300,300])
h1=scatter(Omega_Inst,A_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([26.7,29])
ylim([0,1.8])
xlabel('$\omega_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

h_f=figure(2);
set(h_f,'Position',[100,100,300,300])
h2=scatter(A_Inst,V_Inst,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,1.8])
ylim([-0.15,0])
xlabel('$a_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
ylabel('$\dot{a}_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',12)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)

h_f=figure(3);
set(h_f,'Position',[50,50,300,300])
h3=scatter(A_Inst.^2,Stream,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
xlim([0,3])
ylim([-0.4,0.4])
xlabel('$a_{1,1}^2(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$s_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
grid on
box on
set(gca,'FontName','Times New Roman','FontSize',12)


lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para0=[27,5];
Para=lsqcurvefit(@(Para,x)Backbone_Fit(Para,x),Para0,A_Inst,Omega_Inst,[],[],lsq_options);
omega1=Para(1)
eta2=Para(2)

figure(1)
hold on
h3=plot(Backbone_Fit(Para,A_Inst),A_Inst,'k','LineWidth',1.5);

Para0=0.02;
Para=lsqcurvefit(@(Para,x)Amp_Velo_Fit(Para,x),Para0,A_Inst,V_Inst,[],[],lsq_options);
mu1=Para
figure(2)
hold on
h4=plot(A_Inst,Amp_Velo_Fit(Para,A_Inst),'k','LineWidth',1.5);

% h_f=figure(3);
% set(h_f,'Position',[50,50,500,300])
% h1=scatter(T,Stream,20,'MarkerEdgeColor','none','MarkerFaceColor','r','MarkerFaceAlpha',0.4);
% xlabel('$t$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
% ylabel('$S_{1,1}(\varepsilon t)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
% grid on
% box on
% set(gca,'FontName','Times New Roman','FontSize',11)

function y=Amp_Velo_Fit(Para,x)
mu1=Para;
y=-mu1*x/2;

function y=Backbone_Fit(Para,x)
omega1=Para(1); eta2=Para(2);
y=omega1+3*eta2*x.^2/(8*omega1);