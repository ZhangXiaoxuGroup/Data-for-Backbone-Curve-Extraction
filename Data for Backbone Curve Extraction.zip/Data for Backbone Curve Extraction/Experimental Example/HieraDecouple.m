function [u,rho]=HieraDecouple(u_mn,s_nn,a_nn,phi_nn)
% u_mn, a_nn, phy_nn must be column vectors
Chi=[a_nn.^2,a_nn.^3.*sin(phi_nn),a_nn.^3.*cos(phi_nn),...
    a_nn.^2.*sin(2*phi_nn),a_nn.^2.*cos(2*phi_nn),...
    a_nn.^3.*sin(3*phi_nn),a_nn.^3.*cos(3*phi_nn),...
    s_nn,a_nn.*sin(phi_nn),a_nn.*cos(phi_nn)];
u=u_mn; rho=zeros(9,1);
for n=1:9
    if norm(Chi(:,n)) >1e-1
        rho(n)=(u'*Chi(:,n))/(Chi(:,n)'*Chi(:,n));
        u=u-rho(n)*Chi(:,n);.
    end
end

% rho(1)=(u'*Chi(:,1))/(Chi(:,1)'*Chi(:,1));
% u=u-rho(1)*Chi(:,1);
% rho(4)=(u'*Chi(:,4))/(Chi(:,4)'*Chi(:,4));
% u=u-rho(4)*Chi(:,4);
% rho(5)=(u'*Chi(:,5))/(Chi(:,5)'*Chi(:,5));
% u=u-rho(5)*Chi(:,5);
% rho(8)=(u'*Chi(:,8))/(Chi(:,8)'*Chi(:,8));
% u=u-rho(8)*Chi(:,8);
% rho(9)=(u'*Chi(:,9))/(Chi(:,9)'*Chi(:,9));
% u=u-rho(9)*Chi(:,9);
