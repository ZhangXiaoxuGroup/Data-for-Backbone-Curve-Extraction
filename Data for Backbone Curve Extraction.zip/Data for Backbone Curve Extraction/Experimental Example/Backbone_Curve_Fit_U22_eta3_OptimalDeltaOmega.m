function Backbone_Curve_Fit_U22_eta3_OptimalDeltaOmega
clc; clear; close all;
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
omega1=27.047306461832289;
mu1=0.134586766424387;
omega2=41.664389159075455;
mu2=0.205513124478225;
eta2=44.161879686317661;
eta3=-5.850728871964156e+02;
eta4=2.421443508328958e+02;

Data=load('Experimental Data.mat');
t=Data.t'; NT=length(t);
u22=Data.u22'*100;

Para0=[1.5;0];
lsq_options=optimset('TolFun',1e-6,'TolX',1e-6,'Display','final');
Para=lsqcurvefit(@(Para,t)ResponseFit(Para,t),Para0,t,u22,[],[],lsq_options);
Para
a22_Inst=Para(1)*exp(-mu2/2*t);
omega22=omega2+eta4*(3*a22_Inst.^2)/(8*omega2);
phi22_Inst=cumtrapz(t,omega22)+Para(2);
h2=a22_Inst.^2.*cos(2*phi22_Inst)/2;
U22=fft(u22)/NT*2;
H2=fft(h2)/NT*2;
freq=(1:NT)/(t(end)-t(1));

h_f=figure(1);
set(h_f,'Position',[50,50,250,300])
semilogy(freq*2*pi,abs(U22),'b','LineWidth',1)
hold on
semilogy(freq*2*pi,abs(H2*eta3/(3*omega2^2)),'r','LineWidth',1)
xlim([-2,120])
ylim([-0.5,1.5]*1e-1)

N=round(2*omega2/(2*pi/(t(end)-t(1))));

delta_w=3:0.5:8;
Ld=length(delta_w);
Eta3=zeros(1,Ld);
Ratio=zeros(1,Ld);
for i=1:Ld
    N_delta=round(delta_w(i)/(2*pi/(t(end)-t(1))));
    Eta3(i)=H2((N-N_delta):(N+N_delta))\U22((N-N_delta):(N+N_delta))*(3*omega2^2);
    Ratio(i)=abs(imag(Eta3(i))/real(Eta3(i)))*100;
end
[~,Index]=min(Ratio);
Eta3(Index)

h_f=figure(2);
set(h_f,'Position',[50,50,400,300])
bar(delta_w,Ratio,'FaceColor','b','EdgeColor','None','BarWidth',0.6)
xlabel('$\delta \omega$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
ylabel('$\rho \left( \%  \right)$','Interpreter','Latex','FontName','Times New Roman','FontSize',11)
set(gca,'FontName','Times New Roman','FontSize',11,'YScale','log')
ylim([1e-2,5e3])


function y=ResponseFit(Para,t)
global omega1 mu1 omega2 mu2 eta2 eta3 eta4
a22=Para(1)*exp(-mu2/2*t);
omega22=eta4*(3*a22.^2)/(8*omega2);
phi22=cumtrapz(t,omega22);
y=a22.*cos(omega2*t+phi22+Para(2))-eta3*a22.^2/(2*omega2^2);