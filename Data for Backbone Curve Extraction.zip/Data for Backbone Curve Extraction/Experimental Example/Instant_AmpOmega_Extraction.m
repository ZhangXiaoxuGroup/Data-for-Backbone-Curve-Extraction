function [T,A_Inst,V_Inst,Omega_Inst,Stream]=Instant_AmpOmega_Extraction(t,u)
NT=length(t);
U_Env=[];
L_Env=[];
for n=21:(NT-20)
    if u(n) == max(u((-20:20)+n))
        U_Env=[U_Env,[t(n);u(n)]];
    end
    if u(n) == min(u((-20:20)+n))
        L_Env=[L_Env,[t(n);u(n)]];
    end
end
U_A=interp1(U_Env(1,:),U_Env(2,:),t,'linear');
L_A=interp1(L_Env(1,:),L_Env(2,:),t,'linear');
A_Inst=(U_A-L_A)/2;
Stream=(U_A+L_A)/2;
V_Inst=(A_Inst(2:end)-A_Inst(1:(end-1)))/(t(2)-t(1));
u=u-(U_A+L_A)/2;

Omeg_T=[]; Cross_P=[];
for n=2:NT
    if u(n-1)*u(n) <= 0
        Cross_T=t(n-1)+abs(u(n-1))/(abs(u(n-1))+abs(u(n)))*(t(n)-t(n-1));
        if isempty(Cross_P)
            Cross_P=Cross_T;
        else
            Omeg_T=[Omeg_T,[(Cross_P+Cross_T)/2;pi/(Cross_T-Cross_P)]];
            Cross_P=Cross_T;
        end
    end
end

T=Omeg_T(1,:);
Omega_Inst=Omeg_T(2,:);
A_Inst=interp1(t,A_Inst,T,'spline');
V_Inst=interp1((t(2:end)+t(1:(end-1)))/2,V_Inst,T,'spline');
Stream=interp1(t,Stream,T,'spline');